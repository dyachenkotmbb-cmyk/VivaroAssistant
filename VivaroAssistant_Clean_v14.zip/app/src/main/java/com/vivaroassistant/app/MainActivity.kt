package com.vivaroassistant.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

private val Yellow = Color(0xFFFFD21C)
private val Background = Color(0xFF071014)
private val Card = Color(0xFF111B1F)

private enum class Screen {
    Welcome, Home, OBD2, Service, Fuel, Instructions, DTC, Parts, AI, Useful, Vehicle, Journal, More, Settings
}

private data class HomeAction(
    val title: String,
    val subtitle: String? = null,
    val iconRes: Int,
    val screen: Screen
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        setContent {
            var screen by remember { mutableStateOf(Screen.Welcome) }

            MaterialTheme {
                when (screen) {
                    Screen.Welcome -> VivaroWelcomeScreen(
                        onEnter = { screen = Screen.Home }
                    )
                    Screen.Home -> HomeScreen(
                        onNavigate = { screen = it }
                    )
                    else -> PlaceholderScreen(
                        screen = screen,
                        onBack = { screen = Screen.Home }
                    )
                }
            }
        }
    }
}

@Composable
private fun VivaroWelcomeScreen(onEnter: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.vivaro_scene),
            contentDescription = "Opel Vivaro",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 22.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(R.drawable.opel_logo),
                    contentDescription = "Opel",
                    modifier = Modifier.width(105.dp)
                )
                Text("Vivaro", color = Color.White, fontSize = 35.sp, fontWeight = FontWeight.Bold)
                Text("Assistant", color = Yellow, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Ваш надійний помічник", color = Color.White, fontSize = 19.sp)
                Text("у догляді за автомобілем", color = Color.White, fontSize = 19.sp)

                androidx.compose.material3.Button(
                    onClick = onEnter,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 22.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = Yellow,
                        contentColor = Color.Black
                    )
                ) {
                    Text("Почати", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                }

                Text(
                    "Пропустити",
                    color = Color.White.copy(alpha = .9f),
                    fontSize = 18.sp,
                    modifier = Modifier
                        .clickable(onClick = onEnter)
                        .padding(top = 14.dp, bottom = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(onNavigate: (Screen) -> Unit) {
    val actions = listOf(
        HomeAction("Діагностика", "OBD2", R.drawable.icon_obd2, Screen.OBD2),
        HomeAction("ТО та сервіс", null, R.drawable.icon_service, Screen.Service),
        HomeAction("Витрата", "пального", R.drawable.icon_fuel, Screen.Fuel),
        HomeAction("Інструкції", "та ремонт", R.drawable.icon_instructions, Screen.Instructions),
        HomeAction("Помилки", "(DTC)", R.drawable.icon_dtc, Screen.DTC),
        HomeAction("Запчастини", "та ціни", R.drawable.icon_parts, Screen.Parts),
        HomeAction("AI-помічник", null, R.drawable.icon_ai, Screen.AI),
        HomeAction("Корисне", null, R.drawable.icon_useful, Screen.Useful)
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 18.dp)
                .padding(bottom = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Мій Vivaro",
                        color = Color.White,
                        fontSize = 28.sp,
                        lineHeight = 32.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    "⚙",
                    color = Color.White,
                    fontSize = 31.sp,
                    modifier = Modifier
                        .clickable { onNavigate(Screen.Settings) }
                        .padding(8.dp)
                )
            }

            Spacer(Modifier.height(14.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(265.dp)
                    .background(Card, RoundedCornerShape(2.dp))
            ) {
                Image(
                    painter = painterResource(R.drawable.vivaro_scene),
                    contentDescription = "Vivaro",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                InfoCard(
                    title = "Пробіг",
                    value = "186 420 км",
                    modifier = Modifier.weight(1f)
                )
                InfoCard(
                    title = "Наступне ТО",
                    value = "через 4 580 км",
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(12.dp))

            // Фіксована сітка 2×4. Всі картки мають гарантовану висоту
            // і тому не зникають через проблеми з вимірюванням LazyVerticalGrid.
            actions.chunked(2).forEach { rowActions ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    rowActions.forEach { action ->
                        ActionCard(
                            action = action,
                            onClick = { onNavigate(action.screen) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (rowActions.size == 1) {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }

            Spacer(Modifier.height(150.dp))
        }

        BottomBar(
            selected = Screen.Home,
            onNavigate = onNavigate,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
        )
    }
}

@Composable
private fun InfoCard(title: String, value: String, modifier: Modifier) {
    Column(
        modifier = modifier
            .height(76.dp)
            .background(Card, RoundedCornerShape(20.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            title,
            color = Color.White.copy(alpha = .72f),
            fontSize = 14.sp,
            lineHeight = 17.sp
        )
        Text(
            value,
            color = Color.White,
            fontSize = 17.sp,
            lineHeight = 21.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun ActionCard(
    action: HomeAction,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .height(88.dp)
            .background(Card, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(action.iconRes),
            contentDescription = action.title,
            modifier = Modifier.size(56.dp),
            contentScale = ContentScale.Fit
        )

        Spacer(Modifier.width(6.dp))

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                action.title,
                color = Color.White,
                fontSize = 12.sp,
                lineHeight = 15.sp,
                fontWeight = FontWeight.Bold
            )
            action.subtitle?.let {
                Text(
                    it,
                    color = Color.White,
                    fontSize = 12.sp,
                    lineHeight = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Text(
            "›",
            color = Color.White.copy(alpha = .75f),
            fontSize = 24.sp
        )
    }
}

@Composable
private fun BottomBar(
    selected: Screen,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF0B1519))
            .height(58.dp)
            .padding(horizontal = 6.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        BottomItem("⌂", "Головна", selected == Screen.Home) {
            onNavigate(Screen.Home)
        }
        BottomItem("🚗", "Авто", selected == Screen.Vehicle) {
            onNavigate(Screen.Vehicle)
        }
        BottomItem("◴", "Журнал", selected == Screen.Journal) {
            onNavigate(Screen.Journal)
        }
        BottomItem("☰", "Більше", selected == Screen.More) {
            onNavigate(Screen.More)
        }
    }
}

@Composable
private fun BottomItem(
    icon: String,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 0.dp)
    ) {
        Text(
            icon,
            color = if (selected) Yellow else Color.White,
            fontSize = 18.sp
        )
        Text(
            label,
            color = if (selected) Yellow else Color.White,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun PlaceholderScreen(screen: Screen, onBack: () -> Unit) {
    val title = when (screen) {
        Screen.OBD2 -> "Діагностика OBD2"
        Screen.Service -> "ТО та сервіс"
        Screen.Fuel -> "Витрата пального"
        Screen.Instructions -> "Інструкції та ремонт"
        Screen.DTC -> "Помилки (DTC)"
        Screen.Parts -> "Запчастини та ціни"
        Screen.AI -> "AI-помічник"
        Screen.Useful -> "Корисне"
        Screen.Vehicle -> "Авто"
        Screen.Journal -> "Журнал"
        Screen.More -> "Більше"
        Screen.Settings -> "Налаштування"
        else -> "Vivaro Assistant"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp)
    ) {
        Text(
            "‹",
            color = Color.White,
            fontSize = 40.sp,
            modifier = Modifier.clickable(onClick = onBack)
        )
        Text(title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Text(
            "Сторінка готова для наступного кроку розробки.",
            color = Color.White.copy(.75f),
            fontSize = 17.sp
        )
    }
}
