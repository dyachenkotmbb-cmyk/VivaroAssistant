# VivaroAssistant — clean v1

A completely new Android/Jetpack Compose project for the Vivaro Assistant app.

## Identity
- applicationId: `com.vivaroassistant.app`
- namespace: `com.vivaroassistant.app`
- version: `1.0-clean`

## Scope
This version contains exactly one native Compose screen:
- Opel logo
- Vivaro / Assistant
- Opel Vivaro 2010
- 2.0 Diesel
- Vivaro image
- Ukrainian helper text
- yellow "Почати" button
- "Пропустити"

There is intentionally no "Мій Vivaro", OBD2, maintenance, DTC, fuel, repair, or AI dashboard code.

## Build
Open the project in Android Studio and run the `app` configuration.

For CI, the repository workflow builds `assembleDebug` directly from the project. It does not inspect or extract any ZIP file.
