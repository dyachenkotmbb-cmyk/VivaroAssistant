package com.vivaroassistant.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = false
        setContent {
            VivaroWelcomeScreen()
        }
    }
}

@Composable
private fun VivaroWelcomeScreen() {
    val yellow = Color(0xFFFFD21C)
    val deep = Color(0xFF06131A)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    0f to Color(0xFF06131A),
                    0.34f to Color(0xFF13242B),
                    0.62f to Color(0xFF172A2D),
                    1f to deep
                )
            )
            .padding(horizontal = 24.dp, vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.weight(0.045f))

            Image(
                painter = painterResource(R.drawable.opel_logo),
                contentDescription = "Opel",
                modifier = Modifier
                    .width(112.dp)
                    .weight(0.145f),
                contentScale = ContentScale.Fit
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(0.135f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Vivaro",
                    color = Color.White,
                    fontSize = 37.sp,
                    lineHeight = 40.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Assistant",
                    color = yellow,
                    fontSize = 36.sp,
                    lineHeight = 39.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(0.105f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    "Opel Vivaro 2010",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    "2.0 Diesel",
                    color = Color.White,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Image(
                painter = painterResource(R.drawable.vivaro_scene),
                contentDescription = "Opel Vivaro",
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.355f)
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Crop
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(0.135f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    "Ваш надійний помічник",
                    color = Color.White,
                    fontSize = 20.sp,
                    lineHeight = 25.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    "у догляді за автомобілем",
                    color = Color.White,
                    fontSize = 20.sp,
                    lineHeight = 25.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Button(
                onClick = { },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = yellow,
                    contentColor = Color.Black
                )
            ) {
                Text(
                    "Почати",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(10.dp))

            Text(
                "Пропустити",
                color = Color.White.copy(alpha = 0.75f),
                fontSize = 19.sp,
                modifier = Modifier
                    .padding(bottom = 10.dp)
                    .alpha(0.9f)
            )
        }
    }
}
