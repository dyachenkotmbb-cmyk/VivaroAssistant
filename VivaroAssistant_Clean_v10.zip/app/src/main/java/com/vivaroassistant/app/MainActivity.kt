package com.vivaroassistant.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

private val Yellow = Color(0xFFFFD21C)
private val Background = Color(0xFF071014)
private val Card = Color(0xFF111B1F)
private val CardBorder = Color(0xFF263238)

private enum class Screen {
    Welcome, Home, OBD2, Service, Fuel, Instructions, DTC, Parts, AI, Useful, Vehicle, Journal, More, Settings
}

private data class HomeAction(
    val title: String,
    val subtitle: String? = null,
    val icon: String,
    val screen: Screen
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        setContent {
            var screen by remember { mutableStateOf(Screen.Welcome) }

            MaterialTheme {
                when (screen) {
                    Screen.Welcome -> VivaroWelcomeScreen(
                        onEnter = { screen = Screen.Home }
                    )
                    Screen.Home -> HomeScreen(
                        onNavigate = { screen = it }
                    )
                    else -> PlaceholderScreen(
                        screen = screen,
                        onBack = { screen = Screen.Home }
                    )
                }
            }
        }
    }
}

@Composable
private fun VivaroWelcomeScreen(onEnter: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.vivaro_scene),
            contentDescription = "Opel Vivaro",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 22.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(R.drawable.opel_logo),
                    contentDescription = "Opel",
                    modifier = Modifier.width(105.dp)
                )
                Text("Vivaro", color = Color.White, fontSize = 35.sp, fontWeight = FontWeight.Bold)
                Text("Assistant", color = Yellow, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Ваш надійний помічник", color = Color.White, fontSize = 19.sp)
                Text("у догляді за автомобілем", color = Color.White, fontSize = 19.sp)

                androidx.compose.material3.Button(
                    onClick = onEnter,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 22.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = Yellow,
                        contentColor = Color.Black
                    )
                ) {
                    Text("Почати", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                }

                Text(
                    "Пропустити",
                    color = Color.White.copy(alpha = .9f),
                    fontSize = 18.sp,
                    modifier = Modifier
                        .clickable(onClick = onEnter)
                        .padding(top = 14.dp, bottom = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(onNavigate: (Screen) -> Unit) {
    val actions = listOf(
        HomeAction("Діагностика", "OBD2", "🚘", Screen.OBD2),
        HomeAction("ТО та сервіс", null, "🔧", Screen.Service),
        HomeAction("Витрата", "пального", "⛽", Screen.Fuel),
        HomeAction("Інструкції", "та ремонт", "📖", Screen.Instructions),
        HomeAction("Помилки", "(DTC)", "⚠", Screen.DTC),
        HomeAction("Запчастини", "та ціни", "⚙", Screen.Parts),
        HomeAction("AI-помічник", null, "🤖", Screen.AI),
        HomeAction("Корисне", null, "★", Screen.Useful)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Мій Vivaro", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Opel Vivaro 2010", color = Color.White.copy(.9f), fontSize = 17.sp)
                Text("2.0 Diesel (M9R)", color = Color.White.copy(.9f), fontSize = 17.sp)
            }
            Text(
                "⚙",
                color = Color.White,
                fontSize = 28.sp,
                modifier = Modifier
                    .clickable { onNavigate(Screen.Settings) }
                    .padding(8.dp)
            )
        }

        Spacer(Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(275.dp)
                .background(Card, RoundedCornerShape(24.dp))
        ) {
            Image(
                painter = painterResource(R.drawable.vivaro_scene),
                contentDescription = "Vivaro",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            InfoCard("Пробіг", "186 420 км", Modifier.weight(1f))
            InfoCard("Наступне ТО", "через 4 580 км", Modifier.weight(1f))
        }

        Spacer(Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(actions) { action ->
                ActionCard(action) { onNavigate(action.screen) }
            }
        }

        BottomBar(
            selected = Screen.Home,
            onNavigate = onNavigate
        )
    }
}

@Composable
private fun InfoCard(title: String, value: String, modifier: Modifier) {
    Column(
        modifier = modifier
            .height(78.dp)
            .background(Card, RoundedCornerShape(18.dp))
            .padding(horizontal = 18.dp, vertical = 11.dp)
    ) {
        Text(title, color = Color.White.copy(.72f), fontSize = 15.sp)
        Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ActionCard(action: HomeAction, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(88.dp)
            .background(Card, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            action.icon,
            color = if (action.title == "Діагностика") Yellow else Color.White,
            fontSize = 32.sp,
            modifier = Modifier.width(55.dp)
        )
        Column {
            Text(action.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            action.subtitle?.let {
                Text(it, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun BottomBar(selected: Screen, onNavigate: (Screen) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0B1519))
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        BottomItem("⌂", "Головна", selected == Screen.Home) { onNavigate(Screen.Home) }
        BottomItem("🚗", "Авто", selected == Screen.Vehicle) { onNavigate(Screen.Vehicle) }
        BottomItem("◴", "Журнал", selected == Screen.Journal) { onNavigate(Screen.Journal) }
        BottomItem("☰", "Більше", selected == Screen.More) { onNavigate(Screen.More) }
    }
}

@Composable
private fun BottomItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick).padding(horizontal = 12.dp)
    ) {
        Text(icon, color = if (selected) Yellow else Color.White, fontSize = 24.sp)
        Text(label, color = if (selected) Yellow else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PlaceholderScreen(screen: Screen, onBack: () -> Unit) {
    val title = when (screen) {
        Screen.OBD2 -> "Діагностика OBD2"
        Screen.Service -> "ТО та сервіс"
        Screen.Fuel -> "Витрата пального"
        Screen.Instructions -> "Інструкції та ремонт"
        Screen.DTC -> "Помилки (DTC)"
        Screen.Parts -> "Запчастини та ціни"
        Screen.AI -> "AI-помічник"
        Screen.Useful -> "Корисне"
        Screen.Vehicle -> "Авто"
        Screen.Journal -> "Журнал"
        Screen.More -> "Більше"
        Screen.Settings -> "Налаштування"
        else -> "Vivaro Assistant"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp)
    ) {
        Text(
            "‹",
            color = Color.White,
            fontSize = 40.sp,
            modifier = Modifier.clickable(onClick = onBack)
        )
        Text(title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Text(
            "Сторінка готова для наступного кроку розробки.",
            color = Color.White.copy(.75f),
            fontSize = 17.sp
        )
    }
}
