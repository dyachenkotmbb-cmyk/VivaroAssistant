# VivaroAssistant — clean v3

A completely new Android/Jetpack Compose project for the Vivaro Assistant app.

## Identity
- applicationId: `com.vivaroassistant.app`
- namespace: `com.vivaroassistant.app`
- version: `1.1-welcome`

## Scope
This version contains exactly one native Compose screen:
- Opel logo
- Vivaro / Assistant
- Opel Vivaro 2010
- 2.0 Diesel
- Vivaro image
- Ukrainian helper text
- yellow "Почати" button
- "Пропустити"

There is intentionally no "Мій Vivaro", OBD2, maintenance, DTC, fuel, repair, or AI dashboard code.

## Build
Open the project in Android Studio and run the `app` configuration.

For CI, the repository workflow builds `assembleDebug` directly from the project. It does not inspect or extract any ZIP file.


## Welcome screen v3
The first screen is implemented as native Jetpack Compose UI to closely match the supplied reference. The app launcher icon is included as native mipmap assets.


## v5 visual change
The Vivaro photo is rendered edge-to-edge as the full-screen background. UI elements are native Compose overlays; no screenshot is used as the screen background.

## v7
- Full-screen red Vivaro cinematic background.
- Native Compose UI remains over the background.
- "Почати" and "Пропустити" are active controls.
